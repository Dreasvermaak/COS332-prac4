# COS332-prac4

RUN: 
-javac PhoneBookServer.java Contact.java
-java PhoneBookServer